#!/usr/bin/env python3
"""
inject_and_pack.py
Injects KWFilter.dylib into RXTikTok IPA by:
  1. Unpacking IPA
  2. Patching TikTok stub binary: adds LC_LOAD_DYLIB for KWFilter
  3. Copying KWFilter.dylib to Frameworks/
  4. Stripping old code signature from patched binary
  5. Fake-signing with ldid (no cert needed — sideload tools resign)
  6. Repacking to output IPA

Usage:
  python3 inject_and_pack.py <input.ipa> <KWFilter.dylib> <output.ipa>
"""

import os
import sys
import struct
import shutil
import zipfile
import tempfile
import subprocess

DYLIB_INSTALL_NAME = b"@executable_path/Frameworks/KWFilter.dylib"

# ─── Mach-O helpers ──────────────────────────────────────────────────────────

LC_LOAD_DYLIB       = 0x0000000C
LC_CODE_SIGNATURE   = 0x0000001D
MH_MAGIC_64         = 0xFEEDFACF
FAT_MAGIC           = 0xCAFEBABE  # big-endian

def read32le(data, off): return struct.unpack_from('<I', data, off)[0]
def write32le(buf, off, val): struct.pack_into('<I', buf, off, val)


def inject_lc_load_dylib(binary: bytes, install_name: bytes) -> bytes:
    """
    Appends an LC_LOAD_DYLIB command to a Mach-O binary.
    Strips LC_CODE_SIGNATURE (invalidated by the patch anyway).
    Returns patched bytes.
    """
    data = bytearray(binary)

    magic = read32le(data, 0)
    if magic != MH_MAGIC_64:
        raise ValueError(f"Expected MH_MAGIC_64, got {hex(magic)}")

    ncmds      = read32le(data, 16)
    sizeofcmds = read32le(data, 20)
    header_end = 32 + sizeofcmds

    # ── 1. Check available padding ────────────────────────────────────────────
    # Scan forward from end of load commands for first non-zero byte.
    # The stub binary's __TEXT starts at fileoff=0 so section fileoffs are 0;
    # the actual code starts after a zero-padded gap that insert tools use.
    scan = header_end
    while scan < len(data) and data[scan] == 0:
        scan += 1
    padding_available = scan - header_end

    # LC_LOAD_DYLIB struct:
    # cmd(4) + cmdsize(4) + name_offset(4) + timestamp(4) + current_version(4) + compat_version(4)
    # + name bytes (null-padded to 8-byte alignment)
    name_len    = len(install_name) + 1  # +1 for null terminator
    header_size = 24  # 6 × uint32
    # name field starts at offset 24 from cmd start
    padded_name_len = (name_len + 3) & ~3  # 4-byte align
    new_lc_size = header_size + padded_name_len
    # LC must be 8-byte aligned total
    new_lc_size = (new_lc_size + 7) & ~7

    if new_lc_size > padding_available:
        raise ValueError(
            f"Not enough padding: need {new_lc_size}, have {padding_available}"
        )

    # ── 2. Remove LC_CODE_SIGNATURE ──────────────────────────────────────────
    new_cmds = bytearray()
    off = 32
    removed_sig = False
    for _ in range(ncmds):
        cmd     = read32le(data, off)
        cmdsize = read32le(data, off + 4)
        if cmd == LC_CODE_SIGNATURE:
            removed_sig = True
        else:
            new_cmds += data[off:off + cmdsize]
        off += cmdsize

    # ── 3. Build new LC_LOAD_DYLIB ───────────────────────────────────────────
    new_lc = bytearray(new_lc_size)
    struct.pack_into('<I', new_lc, 0,  LC_LOAD_DYLIB)
    struct.pack_into('<I', new_lc, 4,  new_lc_size)
    struct.pack_into('<I', new_lc, 8,  header_size)   # name offset from start of cmd
    struct.pack_into('<I', new_lc, 12, 0)              # timestamp
    struct.pack_into('<I', new_lc, 16, 0x00010000)     # current_version 1.0
    struct.pack_into('<I', new_lc, 20, 0x00010000)     # compat_version 1.0
    new_lc[header_size:header_size + len(install_name)] = install_name

    new_cmds += new_lc

    # ── 4. Patch header ───────────────────────────────────────────────────────
    new_ncmds = ncmds + 1 - (1 if removed_sig else 0)
    new_sizeofcmds = len(new_cmds)

    result = bytearray(data)
    # Zero out old load commands region
    result[32:header_end] = b'\x00' * sizeofcmds
    # Write new load commands
    result[32:32 + new_sizeofcmds] = new_cmds
    # Update header
    write32le(result, 16, new_ncmds)
    write32le(result, 20, new_sizeofcmds)

    return bytes(result)


def fake_sign(path: str):
    """ldid -S to fake-sign (mark as platform binary, no cert)."""
    try:
        subprocess.check_call(['ldid', '-S', path])
        print(f"  [ldid] signed {os.path.basename(path)}")
    except FileNotFoundError:
        print("  [warn] ldid not found — skipping fake sign (sideload tool will resign)")
    except subprocess.CalledProcessError as e:
        print(f"  [warn] ldid failed: {e}")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    if len(sys.argv) != 4:
        print(f"Usage: {sys.argv[0]} <input.ipa> <KWFilter.dylib> <output.ipa>")
        sys.exit(1)

    input_ipa  = sys.argv[1]
    kwdylib    = sys.argv[2]
    output_ipa = sys.argv[3]

    if not os.path.exists(input_ipa):
        print(f"[error] IPA not found: {input_ipa}"); sys.exit(1)
    if not os.path.exists(kwdylib):
        print(f"[error] dylib not found: {kwdylib}"); sys.exit(1)

    tmpdir = tempfile.mkdtemp(prefix="kwfilter_")
    print(f"[*] Working dir: {tmpdir}")

    try:
        # ── 1. Unpack IPA ─────────────────────────────────────────────────────
        print("[*] Unpacking IPA…")
        with zipfile.ZipFile(input_ipa, 'r') as z:
            z.extractall(tmpdir)

        # Find TikTok stub binary
        payload_dir = os.path.join(tmpdir, 'Payload')
        app_dirs = [d for d in os.listdir(payload_dir) if d.endswith('.app')]
        if not app_dirs:
            raise RuntimeError("No .app found in Payload/")
        app_path = os.path.join(payload_dir, app_dirs[0])
        print(f"[*] App: {app_dirs[0]}")

        # The stub binary has same name as .app without extension
        app_name    = app_dirs[0].replace('.app', '')
        stub_path   = os.path.join(app_path, app_name)
        fw_dir      = os.path.join(app_path, 'Frameworks')

        if not os.path.exists(stub_path):
            raise RuntimeError(f"Stub binary not found: {stub_path}")

        # ── 2. Inject LC_LOAD_DYLIB into stub ────────────────────────────────
        print(f"[*] Patching {app_name} stub binary…")
        with open(stub_path, 'rb') as f:
            stub_data = f.read()

        # Check if already injected
        if DYLIB_INSTALL_NAME in stub_data:
            print("  [info] LC_LOAD_DYLIB already present — skipping inject")
        else:
            patched = inject_lc_load_dylib(stub_data, DYLIB_INSTALL_NAME)
            with open(stub_path, 'wb') as f:
                f.write(patched)
            print(f"  [ok] injected {DYLIB_INSTALL_NAME.decode()}")

        # ── 3. Copy KWFilter.dylib to Frameworks/ ────────────────────────────
        os.makedirs(fw_dir, exist_ok=True)
        dst_dylib = os.path.join(fw_dir, 'KWFilter.dylib')
        shutil.copy2(kwdylib, dst_dylib)
        print(f"[*] Copied KWFilter.dylib → Frameworks/")

        # ── 4. Fake-sign patched binary and dylib ─────────────────────────────
        print("[*] Fake-signing…")
        fake_sign(stub_path)
        fake_sign(dst_dylib)

        # ── 5. Remove old CodeSignature (will be regenerated by sideload tool) ──
        codesig_dir = os.path.join(app_path, '_CodeSignature')
        if os.path.exists(codesig_dir):
            shutil.rmtree(codesig_dir)
            print("[*] Removed _CodeSignature (sideload tool will regenerate)")

        # ── 6. Repack IPA ─────────────────────────────────────────────────────
        print(f"[*] Repacking → {output_ipa}")
        with zipfile.ZipFile(output_ipa, 'w', zipfile.ZIP_DEFLATED,
                             allowZip64=True) as zout:
            for root, dirs, files in os.walk(tmpdir):
                for fname in files:
                    fpath = os.path.join(root, fname)
                    arcname = os.path.relpath(fpath, tmpdir)
                    zout.write(fpath, arcname)

        size_mb = os.path.getsize(output_ipa) / 1024 / 1024
        print(f"[ok] Done: {output_ipa} ({size_mb:.1f} MB)")

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == '__main__':
    main()
