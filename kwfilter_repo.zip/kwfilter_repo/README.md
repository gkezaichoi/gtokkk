# KWFilter

Keyword filter tweak cho RXTikTok 43.9.0.  
Lắc điện thoại → mở menu thêm/xoá keyword.

## Build trên GitHub Actions

### Chỉ lấy dylib (không cần IPA)

1. Push repo lên GitHub (repo private)
2. Actions → `Build KWFilter + Inject IPA` → Run workflow
3. Download artifact `KWFilter-dylib`
4. Tự inject bằng Sideloadly hoặc công cụ khác

### Build + inject thẳng ra IPA

1. Đặt RXTikTok IPA vào thư mục `ipa/` với tên `input.ipa`
2. Thêm vào `.gitignore`:
   ```
   ipa/input.ipa
   output/
   ```
3. **KHÔNG commit IPA lên GitHub** (file 340MB, vi phạm ToS)
4. Push repo → Actions sẽ tự build dylib
5. Sau khi có `KWFilter.dylib`, dùng script inject local:
   ```
   python3 tools/inject_and_pack.py RXTikTok.ipa KWFilter.dylib output.ipa
   ```
   Script chạy được trên Windows (Python 3.8+, không cần dependency nào ngoài stdlib).

## Inject thủ công (nếu không muốn dùng script)

1. Lấy `KWFilter.dylib` từ artifact
2. Dùng **Sideloadly** hoặc **AltStore** → Import IPA → thêm dylib thủ công (tính năng "inject dylib" của Sideloadly)
3. Install bình thường

## Sử dụng

- **Shake** điện thoại khi đang dùng TikTok → popup `KWFilter`
- Enable filter
- Add keyword → nhập từ khoá (không phân biệt hoa thường)
- Video có từ đó trong caption hoặc hashtag sẽ bị ẩn khỏi feed

## Notes

- Không phụ thuộc GTok
- Không xung đột với bất kỳ hook nào của RX
- Settings lưu trong `NSUserDefaults standardUserDefaults` với key prefix `KWFilter*`
- Khi sideload tool (Sideloadly/AltStore) resign IPA, signature mới sẽ cover cả `KWFilter.dylib`
