// KWFilter.mm
// Target : RXTikTok — TikTok 43.9.0 (MusicallyCore, arm64)
// Purpose: Keyword filter for FYP/Following/Search feeds
// UI     : Shake device to open settings menu
// Storage: NSUserDefaults standardUserDefaults
//          KWFilterEnabled  — BOOL
//          KWFilterTerms    — NSArray<NSString *>
// Deps   : libsubstrate.dylib (already bundled in RX IPA)
//          Foundation, UIKit (system)
// Hook points confirmed present in MusicallyCore 43.9.0:
//   AWEListDataController     -appendDataSourceWithAwemes:
//   AWEFeedContainerViewController / TTKFeedContainerViewController
//                             -feedDataChangedWithAwemes:currentIndexInFeed:
//   AWEPlayerManager / TTKFeedPlaybackDataController
//                             -playList:didAddAwemeList:userInfo:
//   (runtime scan)            -searchDataChanged:searchAwemes:
// Build: see Makefile / GitHub Actions workflow

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>

// CydiaSubstrate / ElleKit compatible header
// MSHookMessageEx is present in both
#ifdef __cplusplus
extern "C" {
#endif
void MSHookMessageEx(Class _class, SEL message, IMP hook, IMP *old);
#ifdef __cplusplus
}
#endif

// ─── Keys ────────────────────────────────────────────────────────────────────

static NSString * const kEnabled = @"KWFilterEnabled";
static NSString * const kTerms   = @"KWFilterTerms";

// ─── Filter logic ─────────────────────────────────────────────────────────────

static BOOL kwEnabled(void) {
    return [[NSUserDefaults standardUserDefaults] boolForKey:kEnabled];
}

static NSArray<NSString *> *kwTerms(void) {
    NSArray *t = [[NSUserDefaults standardUserDefaults] arrayForKey:kTerms];
    return (t && [t isKindOfClass:[NSArray class]]) ? t : @[];
}

// Returns YES if aweme should be hidden.
// Reads: desc (NSString), textExtra (array → hashtagName, text).
// Both properties confirmed in AWEAwemeModel 43.9.
static BOOL awemeIsHidden(id aweme) {
    if (!kwEnabled()) return NO;
    NSArray<NSString *> *terms = kwTerms();
    if (!terms.count) return NO;

    NSMutableString *corpus = [NSMutableString stringWithCapacity:256];

    @try {
        NSString *desc = [aweme valueForKey:@"desc"];
        if ([desc isKindOfClass:[NSString class]]) {
            [corpus appendString:desc];
        }

        NSArray *extras = [aweme valueForKey:@"textExtra"];
        if ([extras isKindOfClass:[NSArray class]]) {
            for (id extra in extras) {
                NSString *hn = [extra valueForKeyPath:@"hashtagName"];
                if ([hn isKindOfClass:[NSString class]]) {
                    [corpus appendString:@" "];
                    [corpus appendString:hn];
                }
                NSString *tx = [extra valueForKeyPath:@"text"];
                if ([tx isKindOfClass:[NSString class]]) {
                    [corpus appendString:@" "];
                    [corpus appendString:tx];
                }
            }
        }
    } @catch (NSException *) {
        // valueForKey on unexpected class — skip, don't crash
        return NO;
    }

    if (!corpus.length) return NO;
    NSString *lower = [corpus lowercaseString];

    for (NSString *term in terms) {
        if (!term.length) continue;
        if ([lower containsString:[term lowercaseString]]) return YES;
    }
    return NO;
}

// Filter NSArray of aweme objects. Non-AWEAwemeModel items pass through unchanged
// (ads, cards, banners TikTok injects are separate classes — don't touch them).
static NSArray *filterAwemes(NSArray *awemes) {
    if (!awemes || ![awemes isKindOfClass:[NSArray class]] || !awemes.count) {
        return awemes;
    }
    Class awemeClass = NSClassFromString(@"AWEAwemeModel");
    NSMutableArray *out = [NSMutableArray arrayWithCapacity:awemes.count];
    for (id item in awemes) {
        if (awemeClass && [item isKindOfClass:awemeClass]) {
            if (!awemeIsHidden(item)) [out addObject:item];
        } else {
            [out addObject:item];
        }
    }
    return [out copy];
}

// ─── Hook 1: appendDataSourceWithAwemes: ─────────────────────────────────────
// Class: AWEListDataController
// Called every time the feed appends new content (scroll down, load more).

static void (*orig_appendDataSource)(id, SEL, NSArray *);
static void hook_appendDataSource(id self, SEL _cmd, NSArray *awemes) {
    orig_appendDataSource(self, _cmd, filterAwemes(awemes));
}

// ─── Hook 2: feedDataChangedWithAwemes:currentIndexInFeed: ───────────────────
// Class: AWEFeedContainerViewController (base) or TTKFeedContainerViewController
// Called on initial feed load and full refresh.

static void (*orig_feedDataChanged)(id, SEL, NSArray *, NSInteger);
static void hook_feedDataChanged(id self, SEL _cmd, NSArray *awemes, NSInteger idx) {
    orig_feedDataChanged(self, _cmd, filterAwemes(awemes), idx);
}

// ─── Hook 3: playList:didAddAwemeList:userInfo: ───────────────────────────────
// Class: AWEPlayerManager or TTKFeedPlaybackDataController
// Called when the video player receives new awemes to preload.

static void (*orig_didAddAwemeList)(id, SEL, id, NSArray *, id);
static void hook_didAddAwemeList(id self, SEL _cmd, id playlist, NSArray *list, id info) {
    orig_didAddAwemeList(self, _cmd, playlist, filterAwemes(list), info);
}

// ─── Hook 4: searchDataChanged:searchAwemes: ─────────────────────────────────
// Class: found at runtime (name varies across versions)
// Filters search results.

static void (*orig_searchDataChanged)(id, SEL, id, NSArray *);
static void hook_searchDataChanged(id self, SEL _cmd, id data, NSArray *awemes) {
    orig_searchDataChanged(self, _cmd, data, filterAwemes(awemes));
}

// ─── Settings UI ─────────────────────────────────────────────────────────────

static void showKWMenu(UIViewController *presenter) {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    BOOL enabled       = [ud boolForKey:kEnabled];
    NSArray *rawTerms  = [ud arrayForKey:kTerms];
    NSMutableArray<NSString *> *terms = [((rawTerms && [rawTerms isKindOfClass:[NSArray class]])
        ? rawTerms : @[]) mutableCopy];

    NSString *status = [NSString stringWithFormat:@"%@ — %lu keyword(s)",
        enabled ? @"ON ✓" : @"OFF", (unsigned long)terms.count];

    UIAlertController *main = [UIAlertController
        alertControllerWithTitle:@"KWFilter"
        message:status
        preferredStyle:UIAlertControllerStyleActionSheet];

    // Toggle
    [main addAction:[UIAlertAction
        actionWithTitle:(enabled ? @"Disable" : @"Enable")
        style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *_) {
            [ud setBool:!enabled forKey:kEnabled];
            [ud synchronize];
        }]];

    // Add keyword
    [main addAction:[UIAlertAction
        actionWithTitle:@"Add keyword…"
        style:UIAlertActionStyleDefault
        handler:^(UIAlertAction *_) {
            UIAlertController *add = [UIAlertController
                alertControllerWithTitle:@"Add keyword"
                message:@"Videos containing this word in caption or hashtag will be hidden."
                preferredStyle:UIAlertControllerStyleAlert];
            [add addTextFieldWithConfigurationHandler:^(UITextField *tf) {
                tf.placeholder = @"e.g. sponsor";
                tf.autocapitalizationType = UITextAutocapitalizationTypeNone;
                tf.autocorrectionType = UITextAutocorrectionTypeNo;
            }];
            UIAlertAction *addAction = [UIAlertAction
                actionWithTitle:@"Add"
                style:UIAlertActionStyleDefault
                handler:^(UIAlertAction *_) {
                    NSString *term = [add.textFields.firstObject.text
                        stringByTrimmingCharactersInSet:
                        [NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    if (term.length) {
                        [terms addObject:term];
                        [ud setObject:[terms copy] forKey:kTerms];
                        [ud synchronize];
                    }
                }];
            [add addAction:addAction];
            [add addAction:[UIAlertAction actionWithTitle:@"Cancel"
                style:UIAlertActionStyleCancel handler:nil]];
            [presenter presentViewController:add animated:YES completion:nil];
        }]];

    // Remove keyword (only if list non-empty)
    if (terms.count) {
        [main addAction:[UIAlertAction
            actionWithTitle:@"Remove keyword…"
            style:UIAlertActionStyleDestructive
            handler:^(UIAlertAction *_) {
                UIAlertController *rm = [UIAlertController
                    alertControllerWithTitle:@"Remove keyword"
                    message:nil
                    preferredStyle:UIAlertControllerStyleActionSheet];
                for (NSString *t in terms) {
                    [rm addAction:[UIAlertAction
                        actionWithTitle:t
                        style:UIAlertActionStyleDestructive
                        handler:^(UIAlertAction *a) {
                            NSMutableArray *updated = [terms mutableCopy];
                            [updated removeObject:a.title];
                            [ud setObject:[updated copy] forKey:kTerms];
                            [ud synchronize];
                        }]];
                }
                [rm addAction:[UIAlertAction actionWithTitle:@"Cancel"
                    style:UIAlertActionStyleCancel handler:nil]];
                [presenter presentViewController:rm animated:YES completion:nil];
            }]];

        [main addAction:[UIAlertAction
            actionWithTitle:@"Clear all"
            style:UIAlertActionStyleDestructive
            handler:^(UIAlertAction *_) {
                [ud removeObjectForKey:kTerms];
                [ud synchronize];
            }]];
    }

    [main addAction:[UIAlertAction actionWithTitle:@"Close"
        style:UIAlertActionStyleCancel handler:nil]];

    [presenter presentViewController:main animated:YES completion:nil];
}

// Hook UIWindow motionEnded to catch shake
static void (*orig_motionEnded)(id, SEL, UIEventSubtype, UIEvent *);
static void hook_motionEnded(id self, SEL _cmd, UIEventSubtype motion, UIEvent *event) {
    orig_motionEnded(self, _cmd, motion, event);
    if (motion != UIEventSubtypeMotionShake) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIViewController *root = [(UIWindow *)self rootViewController];
        if (!root) return;
        while (root.presentedViewController) root = root.presentedViewController;
        showKWMenu(root);
    });
}

// ─── Constructor ──────────────────────────────────────────────────────────────

__attribute__((constructor))
static void KWFilterInit(void) {
    // Hook 1
    Class cls1 = NSClassFromString(@"AWEListDataController");
    if (cls1 && [cls1 instancesRespondToSelector:@selector(appendDataSourceWithAwemes:)]) {
        MSHookMessageEx(cls1,
            @selector(appendDataSourceWithAwemes:),
            (IMP)hook_appendDataSource,
            (IMP *)&orig_appendDataSource);
    }

    // Hook 2
    SEL feedSel = @selector(feedDataChangedWithAwemes:currentIndexInFeed:);
    Class cls2 = NSClassFromString(@"AWEFeedContainerViewController");
    if (!cls2 || ![cls2 instancesRespondToSelector:feedSel]) {
        cls2 = NSClassFromString(@"TTKFeedContainerViewController");
    }
    if (cls2 && [cls2 instancesRespondToSelector:feedSel]) {
        MSHookMessageEx(cls2, feedSel,
            (IMP)hook_feedDataChanged,
            (IMP *)&orig_feedDataChanged);
    }

    // Hook 3
    SEL plSel = @selector(playList:didAddAwemeList:userInfo:);
    Class cls3 = NSClassFromString(@"AWEPlayerManager");
    if (!cls3 || ![cls3 instancesRespondToSelector:plSel]) {
        cls3 = NSClassFromString(@"TTKFeedPlaybackDataController");
    }
    if (cls3 && [cls3 instancesRespondToSelector:plSel]) {
        MSHookMessageEx(cls3, plSel,
            (IMP)hook_didAddAwemeList,
            (IMP *)&orig_didAddAwemeList);
    }

    // Hook 4 — runtime scan (class name unstable across versions)
    SEL searchSel = @selector(searchDataChanged:searchAwemes:);
    unsigned int count = 0;
    Class *classes = objc_copyClassList(&count);
    for (unsigned int i = 0; i < count; i++) {
        // Check only classes that directly implement the method (not inherited)
        Method m = class_getInstanceMethod(classes[i], searchSel);
        if (m) {
            MSHookMessageEx(classes[i], searchSel,
                (IMP)hook_searchDataChanged,
                (IMP *)&orig_searchDataChanged);
            break;
        }
    }
    free(classes);

    // Shake gesture
    MSHookMessageEx([UIWindow class],
        @selector(motionEnded:withEvent:),
        (IMP)hook_motionEnded,
        (IMP *)&orig_motionEnded);
}
